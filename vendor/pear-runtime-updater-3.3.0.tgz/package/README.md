# pear-runtime-updater

> Listens for OTA Pear App updates

```sh
npm install pear-runtime-updater
```

Listens for P2P over-the-air (OTA) updates for [Pear](https://docs.pears.com) apps. Replicates from a pear upgrade link and emits when a new version is available.

## MVP - EXPERIMENTAL

This boilerplate is MVP and Experimental.

## Usage

Example in node.js:

```js
const PearRuntimeUpdater = require('pear-runtime-updater')
const path = require('path')
const Corestore = require('corestore')
const Hyperswarm = require('hyperswarm')
const goodbye = require('graceful-goodbye')
const { version, upgrade } = require('./package.json')

const store = new Corestore('./my-app/corestore')

function getApp() {
  return path.join(process.resourcesPath, '../..')
}

const updater = new PearRuntimeUpdater({
  dir: path.join(app.getPath('userData')),
  upgrade,
  version,
  app: getApp(), // path to .app / .AppImage
  name: 'name.ext', // <name>.app, <name>.AppImage, <name>.msix
  store
})

await updater.ready()

updater.on('update-scheduled', (delay) => console.log('Update will start in', delay))
updater.on('updating', () => console.log('Update downloading…'))
updater.on('updating-progress', ({ download }) => {
  console.log('Download progress', Math.round(download.progress * 100))
})
updater.on('updated', async () => {
  console.log('Update ready')
  await updater.applyUpdate()
  app.relaunch()
  app.exit(0)
})

const keyPair = await store.createKeyPair('pear-runtime')
const swarm = new Hyperswarm({ keyPair })
swarm.on('connection', (connection) => store.replicate(connection))
swarm.join(updater.drive.core.discoveryKey, {
  client: true,
  server: false
})

// handle teardown
goodbye(async () => {
  await swarm.destroy()
  await updater.close()
  await store.close()
})
```

## Features

- Peer-to-peer over-the-air (P2P OTA) update listening
- Appends update content via [Hyperdrive](https://github.com/holepunchto/hyperdrive)
- Emits when an update is in progress, update diffs, download progress and when it’s ready
- `applyUpdate()` to atomic swap the new build (bundled apps; macOS/Linux)
- Default random update delay to avoid seeder overload on new releases

## API

#### `const updater = new PearRuntimeUpdater(opts)`

- `opts.dir` – (required) Directory to store data (e.g. app data dir).
- `opts.upgrade` – (required) Pear upgrade link (e.g. from `package.json` `upgrade` field).
- `opts.name` – (required) Application name with extension.
- `opts.store` - (required) Pass a [Corestore](https://github.com/holepunchto/corestore) to be used for updates.
- `opts.version` – (optional) Current app version; used to decide if an update should be stored.
- `opts.app` – (optional) Path to the app bundle (for bundled apps; used with `applyUpdate()`).
- `opts.bundled` – (optional) Whether the app is bundled. Defaults to `!!opts.app`.
- `opts.updates` – (optional) Set to false to opt out of updates.
- `opts.delay` – (optional) Upper bound (in ms) for the randomized update mirror delay. Defaults to 3_600_000 (60 minutes).

#### `updater.on('update-scheduled')`

Emitted when a new upgrade drive length is detected and the update has been scheduled with a random delay.

#### `updater.on('updating')`

Emitted when an update is in progress.

#### `updater.on('updating-delta', data)`

Emitted with mirror delta data while mirroring the update.

#### `updater.on('updating-progress', stats)`

Emitted with mirror monitor stats while downloading the update. Use `stats.download.progress` for progress bars.

```js
{
  peers: Number,
  download: {
    bytes: Number,
    blocks: Number,
    speed: Number,
    progress: Number
  },
  upload: {
    bytes: Number,
    blocks: Number,
    speed: Number
  }
}
```

#### `updater.on('updated')`

Emitted when the update is fully downloaded and ready. After this, `updater.next` is the path to the staged update.

#### `updater.next`

After `updated`, the path to the staged update (e.g. for use with `applyUpdate()` or custom install logic).

#### `await updater.applyUpdate()`

Apply the update by swapping the current app with the received build through atomic swap. Only valid after `updated`, when `opts.bundled` is true.

#### `await updater.close()`

Shut it down. You should do this when closing your app for best performance.

## License

Apache-2.0
